MWXUSB.DLL for Windows 
======================

Filename: mwxusb_140528.zip

Content:
	MwxUsb.dll	V4.13.0.0
        Keyhook.dll     V1.0.34.0
	MWXUSB API.pdf	documentation
	demo folder 	source codes and examples 
	Readme.txt	this file


MwxUsb.dll
======================
This dll provides functions to control the USB Keyboard.
Please refer to the documentation "MWXUSB API.pdf" for complete set of functions.

Notes on MWXUSB.DLL on 64bit / X64 systems:
-------------------------------------------
The MWXUSB.DLL and all DLLs below that are 32bit only.
Therefore applications opening the MWXUSB API must be compiled for platform "X86".

Solution 1:
Please compile your application for platform "X86" � instead of "Any" or "X64".

Solution 2:
Alternatively, if you really need 64bit support in your application:
Here you might write a small X86 wrapper software which is interacting with our DLLs.



"keyhook.dll" V1.0.0.34
========================

Use below script to register the subsystem "USB keyhook" to the Windows' System32 folder:
	register-keyhook_USB_sys32.cmd

Notes:
------
Old installations / DriverPack placed the usb keyhook.dll here by default:
	%ProgramFiles%\Preh\DriverPack\USB\keyhook.dll

"Manually" registering the keyhook.dll in your own installation scripts:
	regsvr32.exe <path to keyhook-usb>\keyhook.dll

Unregister:
	regsvr32.exe /u <path to keyhook-usb>\keyhook.dll
 
This new keyhook can control opening of the USB keyboard as described below:
        Reg-Key:	HKEY_LOCAL_MACHINE\SOFTWARE\PREH\Keyboard\usb
        DWORD           DEVICENUMBER

        Default: DEVICENUMBER = 0
        Use DEVICENUMBER = 1 to skip one PrehKeyTec keyboard (2: skip two keyboards)





======================================================================
Annex
======================================================================
Copyright
� Copyright PrehKeyTec GmbH 2014
Published by PrehKeyTec GmbH. Preh KeyTec GmbH reserves the right to update or change the products described in this document as well as the document itself, without prior notice.
This document may not be reproduced, processed or translated into electronic form or other languages without the prior written permission of Preh KeyTec GmbH.

Trademarks
Brands and product names mentioned in this document are trademarks or registered trademarks of their owner. e.g: Windows: Trademark of Microsoft Corporation

Help and Support
Any questions or suggestions to improve our products are welcome.
Please contact our technical support team: support@prehkeytec.de

PrehKeyTec GmbH
Scheinbergweg 10
D-97638 Mellrichstadt
Germany
Email: support@prehkeytec.de
Web:   www.prehkeytec.com

---
2073/prehkeytec/2014-05-28
